#include "../lib/inc/draft3_run.h"
int main(){
    printStars(3,6);
}
